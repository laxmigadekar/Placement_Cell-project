package com.iims.placementcellservice.model;

public interface DriveSummary {
    int getDriveId();
    String getCompanyName();
    String getDriveDate();
    String getDriveLocation();
    String getOfferedCtc();
}
