package com.iims.placementcellservice.model;

import lombok.Data;

@Data
public class LoginDto {
    String username;
    String password;
}
