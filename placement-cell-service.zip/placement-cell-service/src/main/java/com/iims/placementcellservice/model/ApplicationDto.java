package com.iims.placementcellservice.model;

import lombok.Data;

@Data
public class ApplicationDto {

    long applicationId;
    int driveId;
    long studentId;

}
