package com.iims.placementcellservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlacementCellServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
